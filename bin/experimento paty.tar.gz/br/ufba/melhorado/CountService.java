package br.ufba.melhorado;

import java.util.concurrent.atomic.AtomicInteger;

public class CountService {
	//Counters of broken links total number and status returned by HTTP response.
	private AtomicInteger count =new AtomicInteger();
	private AtomicInteger countQueb =new AtomicInteger();
	private AtomicInteger countOk =new AtomicInteger();
	private AtomicInteger countPesq =new AtomicInteger();
	private AtomicInteger countProibido =new AtomicInteger();
	private AtomicInteger countImpedido =new AtomicInteger();
	private AtomicInteger countRedirecionado =new AtomicInteger();
	private AtomicInteger countErroServer =new AtomicInteger();
	private AtomicInteger countUnknownHost =new AtomicInteger();

	private static CountService uniqueInstance = new CountService();

	private CountService() {
	}

	public static synchronized CountService getInstance() {
		if (uniqueInstance == null)
			uniqueInstance = new CountService();

		return uniqueInstance;
	}


	/**************GETS and SETS*************************************/

	public AtomicInteger getCount() {
		return count;
	}

	public void setCount(AtomicInteger count) {
		this.count = count;
	}

	public AtomicInteger getCountQueb() {
		return countQueb;
	}

	public void setCountQueb(AtomicInteger countQueb) {
		this.countQueb = countQueb;
	}

	public AtomicInteger getCountOk() {
		return countOk;
	}

	public void setCountOk(AtomicInteger countOk) {
		this.countOk = countOk;
	}

	public AtomicInteger getCountPesq() {
		return countPesq;
	}

	public void setCountPesq(AtomicInteger countPesq) {
		this.countPesq = countPesq;
	}

	public AtomicInteger getCountProibido() {
		return countProibido;
	}

	public void setCountProibido(AtomicInteger countProibido) {
		this.countProibido = countProibido;
	}

	public AtomicInteger getCountImpedido() {
		return countImpedido;
	}

	public void setCountImpedido(AtomicInteger countImpedido) {
		this.countImpedido = countImpedido;
	}

	public AtomicInteger getCountRedirecionado() {
		return countRedirecionado;
	}

	public void setCountRedirecionado(AtomicInteger countRedirecionado) {
		this.countRedirecionado = countRedirecionado;
	}

	public AtomicInteger getCountErroServer() {
		return countErroServer;
	}

	public void setCountErroServer(AtomicInteger countErroServer) {
		this.countErroServer = countErroServer;
	}

	public AtomicInteger getCountUnknownHost() {
		return countUnknownHost;
	}

	public void setCountUnknownHost(AtomicInteger countUnknownHost) {
		this.countUnknownHost = countUnknownHost;
	}

	public static CountService getUniqueInstance() {
		return uniqueInstance;
	}

}
