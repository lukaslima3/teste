package br.ufba.melhorado;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * responsable for any operation of writing on a result file. It uses the singleton pattern.
 * @author patricia
 *
 */
public class FileManager {
	
	private static FileManager uniqueInstance;
	private BufferedWriter out;

	FileManager() {
	}

	/*public static synchronized FileManager getInstance() {
		if (uniqueInstance == null)
			uniqueInstance = new FileManager();

		return uniqueInstance;
	}*/


	
	/**
	 * opens the file and writes test's initial date and time
	 */
	void openFile(){
		try {
			out = new BufferedWriter(new FileWriter("TesteIdentificacao"));
			String dateTime = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date()); 
			out.write("Início dos testes " + dateTime + "\n" );
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	void closeFile() throws IOException{
		out.close();
	}
	
	void write(String msg){
		try {
			out.write(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * write the final results on a file
	 * @throws IOException 
	 * 
	 */
	void showResults() throws IOException{
		CountService cs = CountService.getInstance();
		
		out.write("/------------------------Resultados Finais ------------------------/" + "\n" );
		out.write("O número total de links pesquisados é:" + cs.getCount() + "\n");
		out.write("O número de links Quebrados é:" + cs.getCountQueb() + "\n");
		out.write("O número de links ok é:" + cs.getCountOk() + "\n");
		out.write("O número de links Proibidos é:" + cs.getCountProibido()+ "\n");
		out.write("O número de métodos impedidos é:" + cs.getCountImpedido()+ "\n");
		out.write("O número de redirecionados é:" + cs.getCountRedirecionado()+ "\n");
		out.write("Erro Server:" + cs.getCountErroServer()+ "\n");
		out.write("Unknown Host Name:" + cs.getCountUnknownHost()+ "\n");
		out.write("O número resposta diferente de 4.. e 200 é:" + cs.getCountPesq() + "\n");
		out.write("/------------------------------------------------------------------/" + "\n");
		String dateTime = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());  
		out.write("Fim dos testes: " + dateTime + "\n");
		System.out.println("Teste finalizado");
	}
	
	
}
